#include "animal.h"
#include <stdio.h>

void func2(){
    printf("And I wanted to get a dog");
}

