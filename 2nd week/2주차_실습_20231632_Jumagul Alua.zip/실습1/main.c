#include "animal.h"
#include <stdio.h>

int main(){
   printf("Hey guys! Here is my story\n");

   func1();
   printf("\n");

   func2();
   printf("\n");

   func3();
   printf("\n");

   return 0;
}
