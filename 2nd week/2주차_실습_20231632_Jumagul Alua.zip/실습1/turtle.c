#include "animal.h"
#include <stdio.h>

void func3(){
     printf("But got a turtle instead");
}
