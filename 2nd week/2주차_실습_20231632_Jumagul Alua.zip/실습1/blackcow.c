#include "animal.h"
#include <stdio.h>

void func1(){
   printf("We were raising a cow years ago");
}

