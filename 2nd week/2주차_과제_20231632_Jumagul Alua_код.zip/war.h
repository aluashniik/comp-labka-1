#ifndef WAR_H
#define WAR_H

void calc (int n, int coef);
void sol(int A, int B, int coef);
void print_res();

#endif


